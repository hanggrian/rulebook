from rulebook_cppcheck.checkers.rulebook_checkers import RulebookTokenChecker
from rulebook_cppcheck.messages import Messages

try:
    from cppcheckdata import Token
except ImportError:
    from cppcheck.Cppcheck.addons.cppcheckdata import Token


class LowercaseFChecker(RulebookTokenChecker):
    """See detail: https://hanggrian.github.io/rulebook/rules/#lowercase-f"""
    ID: str = 'lowercase-f'
    _MSG: str = 'lowercase.f'

    def process_tokens(self, tokens: list[Token]) -> None:
        # checks for violation
        for token in [t for t in tokens if t.isNumber or t.isName]:
            if 'F' not in token.str:
                continue
            if not token.str.replace('.', '').replace('F', '').replace('f', '').isnumeric():
                continue
            self.report_error(token, Messages.get(self._MSG))
