from rulebook_cppcheck.checkers.rulebook_checkers import RulebookChecker
from rulebook_cppcheck.messages import Messages
from rulebook_cppcheck.nodes import prev_sibling

try:
    from cppcheckdata import Scope, Token
except ImportError:
    from cppcheck.Cppcheck.addons.cppcheckdata import Scope, Token


# TODO find out why Enum is not caught in tests
class ClassNameChecker(RulebookChecker):
    """See detail: https://hanggrian.github.io/rulebook/rules/#class-name"""
    ID: str = 'class-name'
    _MSG: str = 'class.name'

    def get_scopeset(self) -> set[str]:
        return {'Class', 'Struct', 'Union', 'Enum'}

    def visit_scope(self, scope: Scope) -> None:
        # checks for violation
        class_name: str | None = scope.className
        if class_name is None or \
            class_name[0].isupper() and \
            '_' not in class_name and \
            not any(a.isupper() and b.isupper() for a, b in zip(class_name, class_name[1:])):
            return
        name_token: Token | None = prev_sibling(scope.bodyStart, lambda t: t.str == class_name)
        self.report_error(
            name_token if name_token is not None else scope.bodyStart,
            Messages.get(
                self._MSG,
                ''.join(
                    p[0].upper() + (p[1:].lower() if p.isupper() else p[1:]) if p else '' for p in
                    class_name.split('_')
                ),
            ),
        )
